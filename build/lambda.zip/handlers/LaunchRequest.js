module.exports = function () {
  this.emit('Introduction');
};