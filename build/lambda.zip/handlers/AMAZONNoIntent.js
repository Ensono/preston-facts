module.exports = function () {
  this.emit('AMAZON.StopIntent');
};