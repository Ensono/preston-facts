module.exports = function () {
  this.emit(':tell', 'Goodbye');
};