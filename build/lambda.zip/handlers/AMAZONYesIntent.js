module.exports = function () {
  this.emit('GetFact');
};