module.exports = function () {
  this.emit(':ask', 'Hello, would you like a fact about preston?', 'Would you like a fact about Preston?');
};